"""Portable paths for the standalone experiment repository."""
from pathlib import Path
import sys

REPO_ROOT = Path(__file__).resolve().parent.parent
ARTIFACT_ROOT = REPO_ROOT / "rebuttal_artifacts"
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))
